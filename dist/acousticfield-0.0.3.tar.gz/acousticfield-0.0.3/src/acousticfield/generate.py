import numpy as np
import pandas as pd
from scipy import signal
from scipy.io import wavfile
from scipy.stats import linregress


def sweep(T, f1=30, f2=22000,filename=None,fs=48000,fade=0.02,order=2):
    '''
    Genera un sweep exponencial de duracion T con frecuencia de sampleo fs desde la frecuencia f1
    hasta f2, lo almacena en filename.wav y guarda el filtro inverso en filename_inv.npy
    como parametros opcionales se pueden modificar el fadein y fadeout de la senal con fade
    usa el metodo de Muller and Massarani, "Transfer Function Measurement with Sweeps" 
    que era el implementado en Matlab. El unico cambio es que puede elegirse el orden del filtro
    '''
    if filename is None:
        filename = 'sweep' + str(T) + 's_' + str(f1) + '_' + str(f2)   
    N = int(T*fs)
    Gd_start = int(np.ceil(min(N/10,max(fs/f1, N/200)))) # inicio del group delay fs/f1 acotado entre N/10 y N/200
    postfade = int(np.ceil(min(N/10,max(fs/f2,N/200)))) # fadeout 
    Nsweep = N - Gd_start - postfade
    tsweep = Nsweep/fs
    # filtros pasabanda para crear la respuesta en frecuencia deseada
    if (f2 < fs/2):
        B2, A2 = signal.butter(order,f2/(fs/2)) # lowpass
        B1, A1 = signal.butter(order,f1/(fs/2),'highpass') # higpass
    else:
        B2 = [1,2,1]
        A2 = B2
        B1, A1 = signal.butter(2,f1/(fs/2),'highpass' ) # order 2
    W1, H1 = signal.freqz(B1,A1,N+1,fs=fs)
    W2, H2 = signal.freqz(B2,A2,N+1,fs=fs)   
    # espectro rosa (-10dB por decada, or 1/(sqrt(f)) 
    mag = np.sqrt(f1/W1[1:])
    mag = np.insert(mag,0,mag[0]) # completamos f=0
    mag = mag*np.abs(H1)*np.abs(H2) # y aplicamos pasabanda\
    Gd = tsweep * np.cumsum(mag**2)/np.sum(mag**2) # calculo del group delay
    Gd = Gd + Gd_start/fs # agrega el predelay
    Gd = Gd*fs/2;   # convierte a samples
    ph = -2.0*np.pi*np.cumsum(Gd)/(N+1) # obtiene la fase integrando el GD
    ph = ph - (W1/(fs/2))*np.mod(ph[-1],2.0*np.pi) # fuerza la fase a terminar en multiplo de 2 pi
    cplx = mag*np.exp(1.0j*ph) # arma el espectro del sweep a partir de la magnitud y la fase
    cplx = np.append(cplx,np.conj(cplx[-2:0:-1])) # completa el espectro con f negativas para sweep real
    sweep = np.real(np.fft.ifft(cplx)) # Y aca esta el sweep finalmente
    sweep = sweep[:N] # recorta a la cantidad de samples original
    w = signal.hann(2*Gd_start) # ventana para fadein
    sweep[:Gd_start] = sweep[:Gd_start]*w[:Gd_start]
    w = signal.hann(2*postfade) # ventana para fadeout
    sweep[-postfade:] = sweep[-postfade:]*w[-postfade:]
    sweep = sweep/max(np.abs(sweep)) # normaliza
    # Calculo del filtro inverso
    sweepfft = np.fft.fft(sweep)
    invsweepfft = 1.0/sweepfft
    #  para evitar divergencias re aplicamos el pasabanda
    W1, H1 = signal.freqz(B1,A1,N,whole=True,fs=fs)
    W2, H2 = signal.freqz(B2,A2,N,whole=True,fs=fs)
    invsweepfftmag  = np.abs(invsweepfft)*np.abs(H1)*np.abs(H2)
    invsweepfftphase = np.angle(invsweepfft)
    invsweepfft = invsweepfftmag*np.exp(1.0j*invsweepfftphase) # resintesis
    np.save(filename + '_inv',invsweepfft) # guarda el filtro inverso en formato npy
    wavfile.write(filename + '.wav',fs,sweep) # guarda el sweep en wav con formato float 32 bits
    return sweep
# MLS Sequence

def puretone(T,f,fs=48000):
    return np.sin(2.0*np.pi*f*np.arange(0,T,1/fs))

def sigmoid(x,x0=0,a=1):
    x1 = 2*(x-x0)/a
    sig = np.where(x1 < 0, np.exp(x1)/(1 + np.exp(x1)), 1/(1 + np.exp(-x1)))
    return sig

def whitenoise(T, flow=None, fhigh=None, fslow=None, fshigh=None, nchannels=1, fs=48000):
    """
    Genera ruido blanco de duracion T limitado en banda entre flow y fhigh (fslow y fshigh dan las pendientes de
    la sigmoidea del limite de banda) puede generar nchannels canales
    """
    nsamples = int(fs*T)
    freqs = np.fft.rfftfreq(nsamples, 1/fs)
    freqs[0] = 1/nsamples
    fmax = freqs[-1]
    if flow is not None:
        if fslow is None:
            fslow=flow
        s1 = sigmoid(freqs/fmax,flow/fmax,fslow/fmax)
    else:
        s1 = 1
    if fhigh is not None:
        if fshigh is None:
            fshigh=fhigh/4.0
        s2 = sigmoid(freqs/fmax,fhigh/fmax,-fshigh/fmax)
    else:
        s2 = 1
    real = s1*s2*np.random.randn(nchannels, freqs.shape[0])
    imag = s1*s2*np.random.randn(nchannels, freqs.shape[0])
    if not nsamples & 1:
        imag[-1] = 0.
    wnoise = np.array(np.fft.irfft(real + 1j*imag),ndmin=2, dtype='float64').T
    wnoise /= np.abs(wnoise).max(axis=0)
    return wnoise

def pinknoise(T, ncols=16, fs=48000):
    """
    Genera ruido rosa de duracion T usando el algoritmo de Voss-McCartney
    ncols: numero de fuente indeptes
    """
    nsamples = int(T*fs)
    array = np.full((nsamples, ncols), np.nan)
    array[0, :] = np.random.random(ncols)
    array[:, 0] = np.random.random(nsamples)
    cols = np.random.geometric(0.5, nsamples)
    cols[cols >= ncols] = 0
    rows = np.random.randint(nsamples, size=nsamples)
    array[rows, cols] = np.random.random(nsamples)
    df = pd.DataFrame(array)
    df.fillna(method='ffill', axis=0, inplace=True)
    pnoise = df.sum(axis=1).values
    pnoise -= np.mean(pnoise)
    pnoise /= np.abs(pnoise).max(axis=0)
    return pnoise


    
    